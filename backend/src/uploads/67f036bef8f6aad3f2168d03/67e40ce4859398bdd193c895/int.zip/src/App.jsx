import React from 'react'
import LandingPage from './pages/landingPage/LandingPage'
import { 
  BrowserRouter as Router, 
  Routes, 
  Route,
  createRoutesFromElements,
  createBrowserRouter,
  RouterProvider 
} from "react-router-dom";
import Userdashboard from './components/userDashboard/Userdashboard';
import Educonnect from'./components/Educonnect/Latest';
import AboutPage from './components/Educonnect/AboutPage';
import Colleges from './components/Educonnect/Colleges';
import CoursesPage from'./components/Educonnect/CoursesPage';
import Pathways from './components/Educonnect/Pathways';

const router = createBrowserRouter(
  createRoutesFromElements(
    <Route>
      <Route path="/" element={<LandingPage />} />
      <Route path="/userdashboard" element={<Userdashboard/>} />
      <Route path="/Educonnect" element={<Educonnect/>} />
      <Route path="/about" element={<AboutPage/>} />
      <Route path="/colleges" element={<Colleges/>} />
      <Route path="/coursespage" element={<CoursesPage/>} />
      <Route path="/pathways" element={<Pathways/>} />
    </Route>
  ),
  {
    future: {
      v7_startTransition: true,
      v7_relativeSplatPath: true
    }
  }
);

function App() {
  return <RouterProvider router={router} />;
}

export default App