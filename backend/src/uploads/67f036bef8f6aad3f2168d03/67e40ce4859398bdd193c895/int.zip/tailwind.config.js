/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        'rose': {
          400: '#FB7185',
          500: '#F43F5E',
        },
      },
      scrollBehavior: {
        'smooth': 'smooth',
      },
      scrollPadding: {
        sm: '1rem',
        DEFAULT: '2rem',
        lg: '4rem',
      },
      scrollMargin: {
        sm: '1rem',
        DEFAULT: '2rem',
        lg: '4rem',
      },
    },
  },
  plugins: [
    require('@tailwindcss/forms'),
  ],
} 